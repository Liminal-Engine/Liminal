#include "Object.hpp"

namespace entity {
    Object::Object(gfx::def::Handle meshHandle) :
    geometry(meshHandle), transform(), material() 
    {}
    Object::Object(Object &&other) noexcept = default;
    Object &Object::operator=(Object &&other) noexcept = default;
    Object::~Object() = default;

} // namespace entity
